java\
 -Djava.library.path=../..\
 -classpath ../../aparapi.jar:extension.jar\
 com.amd.aparapi.sample.extension.Histogram
