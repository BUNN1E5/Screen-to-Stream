java\
 -Djava.library.path=../..\
 -Dcom.amd.aparapi.executionMode=$1\
 -classpath ../../aparapi.jar:extension.jar\
 com.amd.aparapi.sample.extension.SquareExample
